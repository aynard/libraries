GettingStarted.cpp
==================

.. literalinclude:: ../../../../examples_linux/gettingstarted.cpp
    :lines: 7-
    :linenos:
    :lineno-match:
